CREATE MATERIALIZED VIEW elec_aggregate.topic_dev_history_topic_view TO elec_aggregate.topic_dev_history_topic_store
(
    `type` String,
    `event_type` String,
    `original_id` String,
    `device_id` UInt32,
    `room_id` UInt32,
    `hotel_gid` String,
    `use_electric` Float32,
    `save_electric` Float32,
    `runtime` Float32,
    `collect_time` DateTime
)
AS
SELECT type,
       event_type,
       original_id,
       device_id,
       room_id,
       hotel_gid,
       use_electric,
       save_electric,
       runtime,
       toDateTime(collect_time / 1000) AS collect_time
FROM elec_aggregate.topic_dev_history_topic;

