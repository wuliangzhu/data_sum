CREATE MATERIALIZED VIEW elec_aggregate.kafka_cmd_030c_to_data_history TO elec_aggregate.data_history
(
    `original_id` String,
    `device_id` Int32,
    `room_id` Nullable (Int32),
    `hotel_gid` Nullable (String),
    `floatDataMap.data_key` Array (String),
    `floatDataMap.float_value` Array (Float64),
    `collect_time` DateTime
)
AS
SELECT tId                                                                                                         AS original_id,
       deviceId                                                                                                    AS device_id,
       if(isNull(room_id), 0, room_id)                                                                             AS room_id,
       if(isNull(hotel_gid), '0', hotel_gid)                                                                       AS hotel_gid,
       [concat('use_electric', '|', '030C'), concat('save_electric', '|', '030C'), concat('runtime', '|', '030C')] AS `floatDataMap.data_key`,
       [use_elec, save_elec, dTime / 3600000]                                                                      AS `floatDataMap.float_value`,
       collect_time                                                                                                AS collect_time
FROM elec_aggregate.topic_cmd_030c_topic_store AS ah
         LEFT JOIN elec_aggregate.ac_device ON ah.deviceId = toInt32(id);

