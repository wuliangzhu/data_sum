CREATE MATERIALIZED VIEW elec_aggregate.kafka_dev_history_topic_to_data_history TO elec_aggregate.data_history
(
    `original_id` String,
    `device_id` UInt32,
    `room_id` UInt32,
    `hotel_gid` String,
    `floatDataMap.data_key` Array (String),
    `floatDataMap.float_value` Array (Float32),
    `collect_time` DateTime
)
AS
SELECT original_id,
       device_id,
       room_id,
       hotel_gid,
       [if(length(event_type) = 0, 'use_electric', concat('use_electric', '|', event_type)), if(length(event_type) = 0,
                                                                                                'save_electric',
                                                                                                concat('save_electric', '|', event_type)), if(
               length(event_type) = 0, 'runtime', concat('runtime', '|', event_type))] AS `floatDataMap.data_key`,
       [use_electric, save_electric, runtime]                                          AS `floatDataMap.float_value`,
       collect_time                                                                    AS collect_time
FROM elec_aggregate.topic_dev_history_topic_store;

