CREATE MATERIALIZED VIEW elec_aggregate.topic_cmd_030c_topic_view TO elec_aggregate.topic_cmd_030c_topic_store
(
    `tId` String,
    `deviceId` Int32,
    `totalElectric` Float32,
    `use_elec` Float32,
    `save_elec` Float32,
    `dTime` UInt64,
    `collect_time` DateTime
)
AS
SELECT tId,
       deviceId,
       totalElectric,
       use_elec,
       save_elec,
       dTime,
       toDateTime(collectTime / 1000) AS collect_time
FROM elec_aggregate.topic_cmd_030c_topic;

