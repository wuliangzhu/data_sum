CREATE MATERIALIZED VIEW elec_aggregate.data_history_month_hotel_view TO elec_aggregate.data_history_month_hotel
(
    `hotel_gid` String,
    `int32DataMap.data_key` Array (String),
    `int32DataMap.int_value` Array (UInt32),
    `int64DataMap.data_key` Array (String),
    `int64DataMap.int_value` Array (UInt64),
    `floatDataMap.data_key` Array (String),
    `floatDataMap.float_value` Array (Float32),
    `collect_time` UInt32
)
AS
SELECT hotel_gid,
       int32DataMap.data_key,
       `int32DataMap.int_value`,
       int64DataMap.data_key,
       int64DataMap.int_value,
       floatDataMap.data_key,
       `floatDataMap.float_value`,
       toYYYYMM(collect_time) AS collect_time
FROM elec_aggregate.data_history;

